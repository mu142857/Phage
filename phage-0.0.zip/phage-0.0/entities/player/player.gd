# res://entities/player/player.gd
class_name Player
extends CharacterBody2D

# ============================================================
# Constants - tweak here, applies to all states
# ============================================================
const GRAVITY: float = 1000.0
const MAX_HEALTH: int = 100
const IDLE_TO_CONTRACT_TIME: float = 3.0
const INVINCIBLE_DURATION: float = 0.3
# 战吼式锁定解锁后的余量无敌:很多弹幕不会因为战吼消失(远程蜘蛛等),
# 吼完立刻挨打太冤,解锁后再送这么久的闪烁无敌兜底。
const CUTSCENE_LINGER_INVINCIBLE: float = 1.0

# ---- 护盾机制 ----
# 基础一层护盾;森林的谢礼再附加两层(共3),充能排队制。
# 有盾(拿出护盾)时被碰:破当前盾、进短无敌、不掉血。
# 无盾(没拿出护盾)时被碰:直接死亡。
# 开盾键 E(Backpack): 无盾且有就绪的盾时拿出;有盾时按了没反应。
# 自动开盾(床边选项 Story.auto_shield):有就绪盾就自动拿出,E 变成纯手动备份。
# 破盾键 R(ShieldBreak): 有盾时主动敲碎当前盾——照常进充能、照常触发
# 破盾特效(珊瑚水刺等),但不给无敌(无敌只属于挨打)。
const SHIELD_COUNT: int = 1
const SHIELD_RECHARGE_TIME: float = 5.0    # 基础盾(槽0)充能秒数(2026-08-22 从10砍半)

# ---- Buff 数值(定义/文案见 BuffDefs;获得状态在 Story.buffs_owned) ----
const TABLE_BREAK_INVINCIBLE: float = 2.0   # 愈合的伤口:破盾后无敌时长
const GREEN_RECHARGE_EXTRA: float = 10.0    # 森林的谢礼:附加绿盾充能+10s(5→15)
const FLOWER_RECHARGE_EXTRA: float = 5.0    # 绽放的代价:全部护盾充能+5s(速度1/2,2026-08-27从+10回调)
const LAMP_ENERGY_MAX: int = 8              # 城市的心跳:攒满所需命中次数
const LAMP_FIRE_DURATION: float = 6.0       # 城市的心跳:火光持续时间
const LAMP_ATTACK_SPEED_BONUS: float = 0.3  # 城市的心跳:火光期攻速+30%(加法池)
const WINDOW_RAMP_RATE: float = 0.05        # 窗边的晨光:持盾时每秒+5%攻速
const WINDOW_RAMP_MAX_TIME: float = 4.0     # 窗边的晨光:4秒到顶(+20%)
const TIDE_DAMAGE_BONUS: float = 0.2        # 珊瑚潮汐:冲刺后下一击+20%(加法叠加)
const TIDE_SPIKE_DAMAGE: int = 40           # 珊瑚潮汐:水刺单发伤害(开盾也放后从60下调)
const TIDE_SPIKE_SCALE: float = 1.5         # 珊瑚潮汐:水刺整体放大(更显眼)
const TIDE_RING_BONUS_HITS: int = 4         # 珊瑚潮汐:命中≥这么多根触发下一击强化
const TIDE_ALL_HIT_BONUS: float = 0.5       # 珊瑚潮汐:水刺够数命中→下一击+50%(加法叠加)
const MUZI_REVIVE_INVINCIBLE: float = 1.2   # 沐子的守望:复活后无敌
const MIST_DURATION: float = 3.0            # 礼拜日的云雾:隐身无敌时长
const MIST_COOLDOWN: float = 5.0            # 礼拜日的云雾:冷却(从雾散那刻起算)
const MIST_ALPHA: float = 0.5               # 雾中的半透明度
const TIDE_SPIKE_SCENE: PackedScene = preload("res://entities/player/BuffEffect/water_tank_bullet.tscn")
const EGG_SCENE: PackedScene = preload("res://entities/spider_egg/spider_egg.tscn")
# Buff 时刻的粒子(落地粒子的变色副本,配方见 BuffEffect 目录)
const MUZI_REVIVE_EFFECT_SCENE: PackedScene = preload("res://entities/player/BuffEffect/muzi_revive_effect.tscn")
const SHIELD_READY_EFFECT_SCENE: PackedScene = preload("res://entities/player/BuffEffect/shield_ready_effect.tscn")
const CRYSTAL_DASH_EFFECT_SCENE: PackedScene = preload("res://entities/player/BuffEffect/crystal_dash_effect.tscn")
const LAMP_IGNITE_EFFECT_SCENE: PackedScene = preload("res://entities/player/BuffEffect/lamp_ignite_effect.tscn")
const GREEN_BREAK_EFFECT_SCENE: PackedScene = preload("res://entities/player/BuffEffect/green_shield_break_effect.tscn")
const RUN_SPEED: float = 70.0 #(100.0)
const SPRINT_SPEED: float = 220.0
const SPRINT_COOLDOWN: float = 0.75
const WEB_SNARE_SPEED_MULT: float = 0.12  # 被金盏的网粘住时的移速倍率（基本动不了）
const JUMP_SPEED: float = -200.0
const MAX_JUMP_HOLD_TIME: float = 0.14
const JUMP_HOLD_GRAVITY_MULTIPLIER: float = 0.35
const MAX_JUMP_APEX_HANG_TIME: float = 0.08
const JUMP_APEX_VELOCITY_THRESHOLD: float = 24.0
const JUMP_APEX_GRAVITY_MULTIPLIER: float = 0.18
const LANDING_EFFECT_SCENE: PackedScene = preload("res://entities/player/player_jumping_effect.tscn")
const SHIELD_LANDING_EFFECT_SCENE: PackedScene = preload("res://entities/player/shield_player_jumping_effect.tscn")
const HIT_EFFECT_SCENE: PackedScene = preload("res://entities/player/attack_effect.tscn")
const JUMP_ATTACK_EFFECT_SCENE: PackedScene = preload("res://entities/player/jump_attack_effect.tscn")
const DEATH_EFFECT_SCENE: PackedScene = preload("res://entities/player/player_death_effect.tscn")

const STATE_NULL: int = 0
const STATE_IDLE: int = 1
const STATE_RUN: int = 2
const STATE_FALL: int = 3
const STATE_JUMP: int = 4
const STATE_SPRINT: int = 5
const STATE_CONTRACT: int = 6
const STATE_BALL: int = 7
const STATE_UNCONTRACT: int = 8
const STATE_ATTACK_1: int = 9

# Maximum downward speed (terminal velocity). Normal jumps shouldn't hit this.
const MAX_FALL_SPEED: float = 600.0
const FALL_GRAVITY_MULTIPLIER: float = 1.6
const COYOTE_TIME: float = 0.10
const JUMP_BUFFER_TIME: float = 0.10
# 在地面上连续站稳这么久,当前位置才算"安全点"(避免擦着地刺滑过时被误记)。
const SAFE_RECORD_SETTLE_TIME: float = 0.12
# 安全点离平台左右边缘至少留这么多像素(主角半宽),免得复活在边缘直接滑落。
const SAFE_EDGE_MARGIN: float = 2.0
# 侧向探针在地面接触点上下各探这么多像素(够覆盖落差,又不会探到下层平台)。
const SAFE_GROUND_PROBE_HEIGHT: float = 6.0

var _grounded_time: float = 0.0

# ============================================================
# State (read by states, written by player or specific states)
# ============================================================
var health: int = MAX_HEALTH
var facing_direction: int = 1  # 1 = right, -1 = left
var can_sprint: bool = true
var is_invincible: bool = false
var is_dying: bool = false  # 死亡序列进行中,避免重复触发
# 战吼/演出期间的静默无敌(不闪烁);解锁时转成一段普通闪烁无敌。
var cutscene_invincible: bool = false
# 战吼式锁定:锁输入但保留重力,空中的主角落回地面(空洞骑士式)。
var _fall_while_locked: bool = false
var is_in_ball_form: bool = false  # true when contracted; modifies hitbox + buffs
var input_locked: bool = false
# 被金盏的网粘住:禁跳跃/禁冲刺/移速打折,把网打破(3下)才解除。
var web_snared: bool = false
var is_stunned: bool = false           # 被惊喜盒子砸中的硬控(不掉血,只锁操作)
var _stun_left: float = 0.0

# 护盾状态: shield_ready[i] 是否就绪; shield_recharge[i] 剩余充能秒数。
# is_guarding = 当前是否拿出了护盾(显示外壳); guard_slot = 拿出的是哪个盾(-1=无)。
var shield_ready: Array[bool] = [true, true]
var shield_recharge: Array[float] = [0.0, 0.0]
var is_guarding: bool = false
var guard_slot: int = -1

# ---- Buff 运行态(战斗内临时状态,进梦重置) ----
var tide_next_hit: bool = false        # 珊瑚潮汐:冲刺后的下一击强化,命中即消耗
var tide_ring_bonus: bool = false      # 珊瑚潮汐:水刺全中的下一击强化,命中即消耗
var crystal_dash_active: bool = false  # 蓝水晶:本次冲刺被水晶包裹(完全免疫)
var _tide_ring_pending: int = 0        # 还在飞的水刺数
var _tide_ring_hits: int = 0
var _egg: Node2D = null                # 蜘蛛的伪装:常驻漂浮卵(格林之子式)
var _lamp_energy: int = 0
var _lamp_fire_left: float = 0.0
var _window_ramp: float = 0.0
var _invincibility_token: int = 0
var _blink_time: float = 0.0           # 无敌期闪烁计时
var mist_active: bool = false          # 礼拜日的云雾:雾中(半透明+完全无敌)
var mist_cooldown_left: float = 0.0    # 雾的冷却(HUD 读它换图标)
var _mist_left: float = 0.0

# ---- 开发者模式 ----
# F1(或 ` 反引号)切换:开启后不死不破盾,全身金色提示。
# 地刺仍会把人弹回安全点(respawn_to_safe 不走 take_damage),方便继续跑图。
var dev_god_mode: bool = false
const DEV_GOD_TINT := Color(1.0, 0.85, 0.45)
# 关卡场景里 Player 实例自带的 modulate(多数房间压暗到 0.685 配合点光),
# 无敌模式的金色只是叠在它上面,关掉要还原它而不是写回纯白。
var _base_modulate: Color = Color.WHITE
# 走路特效当前应否发射(有盾时改由 ShieldPlayerWalkingEffect 发射)。
var _walking_effect_enabled: bool = false

# ============================================================
# Node references
# ============================================================
@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var shield_overlay: AnimatedSprite2D = $AnimatedSprite2D/ShieldOverlay
# 技能特效层(默认隐藏,技能系统开关):蓝水晶包裹/铜灯火光/水族箱水花。
@onready var blue_crystal_overlay: AnimatedSprite2D = $AnimatedSprite2D/BlueCrystalOverlay
@onready var fire_attack_overlay: AnimatedSprite2D = $AnimatedSprite2D/FireAttackOverlay
@onready var water_tank_overlay: AnimatedSprite2D = $AnimatedSprite2D/WaterTankOverlay
@onready var collision_normal: CollisionShape2D = $CollisionNormal
@onready var collision_ball: CollisionShape2D = $CollisionBall
@onready var walking_effect: GPUParticles2D = $PlayerWalkingEffect
@onready var shield_walking_effect: GPUParticles2D = $ShieldPlayerWalkingEffect
# 持续状态的身体光环:铜灯火刀期的火焰 / 珊瑚强化未打出时的水珠
@onready var fire_aura: GPUParticles2D = $FireAuraEffect
@onready var tide_aura: GPUParticles2D = $TideAuraEffect
@onready var jump_trail: Node2D = $JumpTrail
@onready var attack_hitbox_1: Area2D = $HitBox/Attack1_1
@onready var attack_hitbox_2: Area2D = $HitBox/Attack1_2
@onready var hitbox_root: Node2D = $HitBox
@onready var state_machine: StateManager = $StateMachine

# ============================================================
# Signals
# ============================================================
signal health_changed(new_health: int)
signal died
# 护盾状态变化(拿出/收起/破盾/充能完成),供以后接 UI 用。
signal shield_changed

func _ready() -> void:
	add_to_group("player")
	_base_modulate = modulate
	set_ball_form(false)
	clear_attack_hitboxes()
	can_sprint = true
	# 盾壳/技能特效都是独立的 overlay 精灵,被动跟随本体的动画帧(不自己 play)。
	sprite.animation_changed.connect(_sync_overlays)
	sprite.frame_changed.connect(_sync_overlays)
	# 按持有的 buff 决定护盾层数(默认1/树=1+2绿),出生全部充满。
	_apply_shield_layout()
	# 中途放下/拿起 buff(左上角 HUD 右键)时,护盾布局和铜灯状态要跟上。
	Story.buff_gained.connect(_on_buffs_changed)
	Story.buff_removed.connect(_on_buffs_changed)
	# 蜘蛛的伪装常驻卵:等场景就位后自动出场(current_scene 此刻可能还没赋值)。
	_update_egg_companion.call_deferred()
	# 每次出生(新梦/死亡重试)守望都完好如初。
	Story.set_muzi_broken(false)
	# 出生默认拿出一个盾(绿盾优先顶上,基础盾留最后),否则一出生被碰就死。
	is_guarding = true
	guard_slot = _first_ready_shield()
	_refresh_shield_visual()
	# 左上角 HUD 的护盾计数跟着本实例走
	Game.buff_hold.call("bind_player", self)
	shield_changed.emit()

# 像素对齐:物理体停在浮点坐标(保证移动/相机插值丝滑),
# 只把渲染用的 sprite 节点局部偏移到整数像素,消除脚底与地板间的亚像素缝隙。
# 只吸附 Y 轴 —— 缝隙是垂直方向的,横向不碰,避免水平移动出现像素跳动。
# 在 _process(渲染帧)里做,不污染物理状态。
func _process(_delta: float) -> void:
	if not is_instance_valid(sprite):
		return
	# 让 sprite.global_position.y 落到整数:补偿父级(物理体)的小数残差。
	sprite.position.y = roundf(global_position.y) - global_position.y
	# 雾中恒定半透明;无敌期闪烁(桌子的长无敌全靠它读出来,挨打短无敌也生效)。
	# 用 self_modulate 不碰 modulate(攻击发光在用)也不影响盾壳等子层。
	if mist_active:
		sprite.self_modulate.a = MIST_ALPHA
	elif is_invincible and not dev_god_mode:
		_blink_time += _delta
		sprite.self_modulate.a = 0.45 if fmod(_blink_time, 0.16) < 0.08 else 1.0
	elif sprite.self_modulate.a < 1.0:
		sprite.self_modulate.a = 1.0
		_blink_time = 0.0

func _physics_process(_delta: float) -> void:
	# 开发者模式切换不受 input_locked 限制,任何时候都能开关。
	if Input.is_action_just_pressed(&"dev_god_mode"):
		_toggle_dev_god_mode()
	_update_shield_recharge(_delta)
	_realign_guard_slot()  # 每帧强制:举的必须是编号最大的就绪盾(防外部改数组不重排)
	_update_buff_timers(_delta)
	_update_stun(_delta)
	# 战吼式锁定期间保留重力:空中被吼就落回地面站好,别悬在天上挨弹幕。
	if input_locked and _fall_while_locked and not is_dying and not is_on_floor():
		if is_instance_valid(sprite) and sprite.animation != &"Fall":
			play_anim(&"Fall")
		velocity.x = 0.0
		apply_gravity(_delta, FALL_GRAVITY_MULTIPLIER)
		move_and_slide()
		if is_on_floor():
			velocity = Vector2.ZERO
			reached_terminal = false
			spawn_landing_effect()
			play_anim(&"Idle")
	if not input_locked and Input.is_action_just_pressed(&"Backpack"):
		raise_shield()
	# 自动开盾(床边选项):有就绪的盾就自动拿出
	if Story.auto_shield and not input_locked and not is_guarding and not is_dying:
		raise_shield()
	if not input_locked and Input.is_action_just_pressed(&"Mist"):
		_try_start_mist()
	if not input_locked and Input.is_action_just_pressed(&"ShieldBreak"):
		manual_break_shield()

	# 持续记录最后的安全落脚点,供地刺等危险物弹回使用。
	# 站稳一小会儿才记录;受伤无敌期间不记录(刚被弹回时别立刻覆盖);
	# 脚下是陷阱平台(unsafe_ground 组)时不记录,免得重生在陷阱上。
	# 只在"平台内侧"记录:脚下左右各 SAFE_EDGE_MARGIN 处都得有地面。
	# 这样贴地走下平台时(土狼时间内中心已越过边缘的那几帧)不会被记录,
	# 自动保留上一个内侧安全点,避免复活在悬空边缘后直接滑落。
	if is_on_floor() and not _is_on_unsafe_ground():
		_grounded_time += _delta
		if _grounded_time >= SAFE_RECORD_SETTLE_TIME and not is_invincible and _is_interior_floor_spot():
			Game.record_safe_position(global_position)
	else:
		_grounded_time = 0.0

# 脚下左右两侧 SAFE_EDGE_MARGIN 处都有地面 → 站在平台内侧(非边缘悬空)。
func _is_interior_floor_spot() -> bool:
	var ground_y := _floor_contact_y()
	if is_inf(ground_y):
		return true  # 拿不到接触点时不阻止记录(退回原行为)
	return _has_ground_below(global_position.x - SAFE_EDGE_MARGIN, ground_y) \
		and _has_ground_below(global_position.x + SAFE_EDGE_MARGIN, ground_y)

# 脚下地面接触点的 Y(全局),取不到返回 INF。
func _floor_contact_y() -> float:
	for i in get_slide_collision_count():
		var collision := get_slide_collision(i)
		if collision.get_normal().y < -0.5:  # 只看脚下(法线朝上)的接触面
			return collision.get_position().y
	return INF

# 在 (x, ground_y) 附近上下各探一小段,判断该处脚下是否有地面。
func _has_ground_below(x: float, ground_y: float) -> bool:
	var space := get_world_2d().direct_space_state
	var from := Vector2(x, ground_y - SAFE_GROUND_PROBE_HEIGHT)
	var to := Vector2(x, ground_y + SAFE_GROUND_PROBE_HEIGHT)
	var query := PhysicsRayQueryParameters2D.create(from, to, collision_mask, [get_rid()])
	return not space.intersect_ray(query).is_empty()

# 检查脚下踩着的碰撞体是否属于 "unsafe_ground" 组(陷阱平台)。
func _is_on_unsafe_ground() -> bool:
	for i in get_slide_collision_count():
		var collision := get_slide_collision(i)
		# 只看脚下(法线朝上)的接触面
		if collision.get_normal().y < -0.5:
			var collider := collision.get_collider()
			if collider is Node and (collider as Node).is_in_group("unsafe_ground"):
				return true
	return false

# 被地刺等危险物击中时调用:弹回上一个安全点,清零速度并给无敌帧。
func respawn_to_safe() -> void:
	if not Game.has_safe_position:
		return
	global_position = Game.last_safe_position
	velocity = Vector2.ZERO
	_grounded_time = 0.0
	change_state(STATE_IDLE)
	_start_invincibility()

func change_state(state_id: int) -> void:
	state_machine.change_state(state_id)

func set_lock(locked: bool) -> void:
	input_locked = locked
	if locked:
		set_ball_form(false)
		change_state(STATE_IDLE)
		velocity = Vector2.ZERO
		clear_attack_hitboxes()
	else:
		# 任何解锁路径都清掉战吼式锁定的痕迹,避免无敌/坠地标记卡死;
		# 演出无敌不立刻掐掉,转成一段闪烁无敌(残留弹幕兜底)。
		_fall_while_locked = false
		if cutscene_invincible:
			cutscene_invincible = false
			_start_invincibility(CUTSCENE_LINGER_INVINCIBLE)
	if is_instance_valid(state_machine):
		state_machine.set_process(not locked)
		state_machine.set_physics_process(not locked)

## 战吼式锁定(BossIntro/各 Battlecry 状态用),比 set_lock 多两件事:
## 1) 锁定期间保留重力,空中的主角像空洞骑士一样落回地面站好;
## 2) 全程无敌 + 解锁后一小段闪烁无敌——战吼不清场上弹幕,靠无敌兜底,
##    不用每种弹幕单独接战吼冻结。
func set_battlecry_lock(locked: bool) -> void:
	if locked:
		set_lock(true)
		_fall_while_locked = true
		cutscene_invincible = true
	else:
		set_lock(false)  # 解锁分支会清坠地标记并发余量无敌

## 硬控(木偶师的惊喜盒子调用):锁操作 duration 秒,不掉血、不破盾。
## 复用战吼式锁定的坠地逻辑(空中被砸也会落地站好),但不给无敌——控住的时候照样能被打。
func apply_stun(duration: float) -> void:
	if is_dying or dev_god_mode or cutscene_invincible:
		return
	if input_locked and not is_stunned:
		return  # 演出锁定中不叠加
	_stun_left = maxf(_stun_left, duration)
	if not is_stunned:
		is_stunned = true
		set_lock(true)
		_fall_while_locked = true


func _update_stun(delta: float) -> void:
	if not is_stunned:
		return
	_stun_left -= delta
	if _stun_left <= 0.0 or is_dying:
		_stun_left = 0.0
		is_stunned = false
		if not is_dying:
			set_lock(false)


## 蛛网缠身开关(金盏网弹调用):true=禁跳/禁冲/减速,false=解除。
func set_web_snared(snared: bool) -> void:
	web_snared = snared

## 当前水平移速(Run/Fall 状态用),缠身时打折。
func run_speed() -> float:
	return RUN_SPEED * (WEB_SNARE_SPEED_MULT if web_snared else 1.0)

func _toggle_dev_god_mode() -> void:
	dev_god_mode = not dev_god_mode
	# 用根节点 modulate 做金色提示,不碰 sprite.modulate(攻击发光在用它)。
	# 金色乘在关卡自带的 modulate 上,关掉还原关卡那份,别把压暗抹成纯白。
	modulate = _base_modulate * DEV_GOD_TINT if dev_god_mode else _base_modulate
	print("[DEV] 无敌模式: ", "开" if dev_god_mode else "关")

func take_damage(_amount: int) -> void:
	if dev_god_mode:
		# 开发者模式:不掉血不破盾,只给短无敌,免得贴着怪连帧触发。
		_start_invincibility()
		return
	if crystal_dash_active:
		return  # 蓝水晶:水晶包裹的冲刺,完全免疫
	if mist_active:
		return  # 礼拜日的云雾:雾中完全免疫
	if cutscene_invincible:
		return  # 战吼/演出锁定期间完全免疫(残留弹幕打不到)
	if is_invincible:
		return
	if is_guarding:
		# 有盾:破当前盾、开始充能、进入无盾(不掉血)。愈合的伤口把无敌延长到 1 秒。
		_break_guard_shield()
		Game.play_hit_feedback()
		_start_invincibility(TABLE_BREAK_INVINCIBLE if has_buff(&"Table") else INVINCIBLE_DURATION)
		return
	# 无盾:沐子的守望可以带盾再站起来一次(之后破碎,本次尝试内无效),否则直接死亡。
	if has_buff(&"MuziPaint") and not Story.muzi_broken:
		_muzi_revive()
		return
	health = 0
	health_changed.emit(health)
	_die()

## 氧气见底之类的"环境死亡":绕过护盾/守望/无敌,当场倒下。
func die_instantly() -> void:
	if is_dying or dev_god_mode:
		return
	health = 0
	health_changed.emit(health)
	_die()


# 蔚蓝式死亡:原地炸开 → 冻结/隐藏 → 交给 Game 黑屏重载房间(清怪+回出生点)。
func _die() -> void:
	if is_dying:
		return
	is_dying = true
	died.emit()
	_spawn_oneshot_particles(DEATH_EFFECT_SCENE)  # 在死亡位置炸开(先炸再隐藏)
	set_lock(true)                                # 冻结输入/状态机
	set_jump_trail(false)
	set_walking_effect(false)
	velocity = Vector2.ZERO
	if is_instance_valid(sprite):
		sprite.visible = false
	Game.handle_player_death()

# ============================================================
# 护盾
# ============================================================
# 排队充能:同一时间只充一个。恢复从上往下(槽0普通盾最先回→绿1→绿2),
# 破盾从下往上(见 _first_ready_shield/_realign_guard_slot)——用户定案。
func _update_shield_recharge(delta: float) -> void:
	for i in shield_recharge.size():
		if shield_ready[i]:
			continue
		shield_recharge[i] = maxf(shield_recharge[i] - delta, 0.0)
		if shield_recharge[i] <= 0.0:
			shield_ready[i] = true
			# 充能完成的绿光一闪:没有它,"盾回来了"只能靠猜
			_spawn_oneshot_particles(SHIELD_READY_EFFECT_SCENE)
			_realign_guard_slot()  # 绿盾充好了就顶到基础盾前面挨打
			shield_changed.emit()
		break  # 只充这一个,后面的排队

## 一键回满所有护盾(boss rush 场间恢复等外部调用):填满+清计时+重新对齐。
func restore_all_shields() -> void:
	for i in shield_ready.size():
		shield_ready[i] = true
		shield_recharge[i] = 0.0
	if not is_guarding:
		raise_shield()
	_realign_guard_slot()
	_refresh_shield_visual()
	shield_changed.emit()


## 守护槽对齐:任何时刻都让编号最大的就绪盾顶在前面(绿盾先挨打,基础盾垫后)。
## 只换"举着哪个",不消耗任何东西;层数变化和充能完成后都要过一遍。
func _realign_guard_slot() -> void:
	if not is_guarding:
		return
	var best := _first_ready_shield()
	if best != -1 and best != guard_slot:
		guard_slot = best
		shield_changed.emit()


# 开盾取"编号最大的就绪盾":绿盾先顶上去挨打,最上面的基础盾留到最后。
func _first_ready_shield() -> int:
	for i in range(shield_ready.size() - 1, -1, -1):
		if shield_ready[i]:
			return i
	return -1

# 开盾键 E:无盾时拿出下一个就绪的盾;已有盾时无事发生。
# (收盾没有免费出口——想进无盾伤害加成,用 R 敲碎它,付一个盾的代价。)
func raise_shield() -> void:
	if is_guarding:
		return
	var slot := _first_ready_shield()
	if slot == -1:
		return  # 没有就绪的盾可拿
	is_guarding = true
	guard_slot = slot
	# 开盾的视觉反馈就是盾壳 overlay 出现,不需要额外特效。
	_refresh_shield_visual()
	shield_changed.emit()
	# 珊瑚潮汐:开盾也激起水刺(和破盾同款扇形)
	if has_buff(&"Watertank"):
		_fire_tide_ring()

# 破盾键 R:主动敲碎当前盾。走和挨打完全一样的破盾流程(充能、珊瑚水刺等
# 破盾特效),区别只在不给无敌帧——无敌是挨打的补偿,不是按键白送的。
func manual_break_shield() -> void:
	if not is_guarding:
		return
	_break_guard_shield()
	Game.shake_camera(2)

func _break_guard_shield() -> void:
	if guard_slot >= 0 and guard_slot < shield_ready.size():
		shield_ready[guard_slot] = false
		shield_recharge[guard_slot] = shield_recharge_time(guard_slot)
		if guard_slot >= 1:
			# 绿盾(森林附加层)碎裂:绿色方粒子从主角身上向上飘散
			_spawn_oneshot_particles(GREEN_BREAK_EFFECT_SCENE)
		# 破盾打断恢复:所有还在充能的盾进度清空,从头再充(挨打会拖垮整条恢复线)
		for i in shield_ready.size():
			if not shield_ready[i]:
				shield_recharge[i] = shield_recharge_time(i)
	is_guarding = false
	guard_slot = -1
	_refresh_shield_visual()
	shield_changed.emit()
	if has_buff(&"Watertank"):
		_fire_tide_ring()

# 统一的播放动画入口(盾壳 overlay 靠信号自动跟帧,这里只管本体)。
func play_anim(anim_name: StringName) -> void:
	if not is_instance_valid(sprite):
		return
	sprite.play(anim_name)

# 护盾拿出/收起:盾壳 overlay 显示/隐藏,本体动画不动,姿势天然不跳帧。
func _refresh_shield_visual() -> void:
	_apply_walking_effect()  # 护盾切换时走路特效也跟着二选一
	set_effect_overlay(shield_overlay, is_guarding)

# 技能特效层开关(蓝水晶包裹/铜灯火光/水族箱水花…同样适用盾壳):
# 开的瞬间立即对齐当前帧,避免露一帧旧画面。
func set_effect_overlay(overlay: AnimatedSprite2D, on: bool) -> void:
	if not is_instance_valid(overlay):
		return
	overlay.visible = on
	if on:
		_sync_one_overlay(overlay)

# 所有 overlay 跟随本体当前动画帧。overlay 从不自己 play,全靠本体的
# animation_changed / frame_changed 信号驱动,不存在漂移。
func _sync_overlays() -> void:
	for child in sprite.get_children():
		var overlay := child as AnimatedSprite2D
		if overlay != null and overlay.visible:
			_sync_one_overlay(overlay)

func _sync_one_overlay(overlay: AnimatedSprite2D) -> void:
	var anim := sprite.animation
	if overlay.sprite_frames == null or not overlay.sprite_frames.has_animation(anim):
		return
	overlay.animation = anim
	overlay.frame = sprite.frame

# 时长可变(愈合的伤口/复活),token 防止旧的短无敌把新的长无敌提前掐掉。
func _start_invincibility(duration: float = INVINCIBLE_DURATION) -> void:
	_invincibility_token += 1
	var token := _invincibility_token
	is_invincible = true
	await get_tree().create_timer(duration).timeout
	if token == _invincibility_token:
		is_invincible = false


# ============================================================
# Buff 效果(获得/文案在 BuffDefs+Story,这里只管战斗内表现)
# ============================================================
func has_buff(id: StringName) -> bool:
	return Story.has_buff(id)


## 护盾层数:默认 1 层;树(森林的谢礼)=1+附加2层(共3)。
## 花不再影响层数(它的代价是恢复变慢,见 shield_recharge_time)。
func _apply_shield_layout() -> void:
	var count := SHIELD_COUNT
	if has_buff(&"Plant"):
		count = 3
	shield_ready.clear()
	shield_recharge.clear()
	for i in count:
		shield_ready.append(true)
		shield_recharge.append(0.0)


## 每个盾位自己的充能时长:槽0(基础)=5s,槽1/2(绿盾)=3倍慢;花再整体×3。
func shield_recharge_time(slot: int = 0) -> float:
	# 减速效果是加法叠(各+10s),不做乘法:基础5/绿盾15/花15/花+绿=25(不是45)。
	var time := SHIELD_RECHARGE_TIME
	if slot >= 1:
		time += GREEN_RECHARGE_EXTRA
	if has_buff(&"Flower"):
		time += FLOWER_RECHARGE_EXTRA
	return time


## 持有 buff 变化(HUD 右键放下等):护盾布局重算(重置为全满),铜灯没了就熄火,
## 蜘蛛卵随 buff 出现/收回。
func _on_buffs_changed(_id: StringName) -> void:
	_apply_shield_layout()
	_realign_guard_slot()  # 层数变了(比如中途拿到森林):绿盾要立刻顶到前面
	if not has_buff(&"CopperLamp"):
		_lamp_energy = 0
		_lamp_fire_left = 0.0
		set_effect_overlay(fire_attack_overlay, false)
		fire_aura.emitting = false
	if not has_buff(&"YunwuPaint"):
		mist_active = false
		mist_cooldown_left = 0.0
	_update_egg_companion()
	shield_changed.emit()


func _update_buff_timers(delta: float) -> void:
	# 城市的心跳:火光倒计时,烧完熄灭
	if _lamp_fire_left > 0.0:
		_lamp_fire_left -= delta
		if _lamp_fire_left <= 0.0:
			set_effect_overlay(fire_attack_overlay, false)
			fire_aura.emitting = false
	# 礼拜日的云雾:无敌倒计时;冷却从雾散后才开始走(不含无敌时间)
	if mist_active:
		_mist_left -= delta
		if _mist_left <= 0.0:
			_end_mist()
	elif mist_cooldown_left > 0.0:
		mist_cooldown_left = maxf(mist_cooldown_left - delta, 0.0)
	# 珊瑚强化在身未打出 → 身上滴水珠
	tide_aura.emitting = tide_next_hit or tide_ring_bonus
	# 窗边的晨光:护盾在身(拿着盾)时攻速逐秒上涨,盾没了立刻清零
	if has_buff(&"Window") and is_guarding:
		_window_ramp = minf(_window_ramp + delta, WINDOW_RAMP_MAX_TIME)
	else:
		_window_ramp = 0.0


## 攻击动画速度倍率(攻击状态套到 sprite.speed_scale 上)。
## 攻速加成走加法池(火刀+30%、窗户至多+20%,同带=+50%),不做乘法。
func attack_speed_multiplier() -> float:
	var bonus := 0.0
	if _lamp_fire_left > 0.0:
		bonus += LAMP_ATTACK_SPEED_BONUS
	if has_buff(&"Window"):
		bonus += WINDOW_RAMP_RATE * _window_ramp
	return 1.0 + bonus


## 攻击力加法增益(设计要求加法叠加,攻击状态算伤害时乘 (1+总和))。
func attack_damage_bonus() -> float:
	var bonus := 0.0
	if tide_next_hit:
		bonus += TIDE_DAMAGE_BONUS
	if tide_ring_bonus:
		bonus += TIDE_ALL_HIT_BONUS
	return bonus


## 攻击命中(至少打中一个目标)回调:消耗潮汐强化、给铜灯攒心跳。
func on_attack_landed() -> void:
	tide_next_hit = false
	tide_ring_bonus = false
	if has_buff(&"CopperLamp") and _lamp_fire_left <= 0.0:
		_lamp_energy += 1
		if _lamp_energy >= LAMP_ENERGY_MAX:
			_lamp_energy = 0
			_lamp_fire_left = LAMP_FIRE_DURATION
			set_effect_overlay(fire_attack_overlay, true)
			fire_aura.emitting = true  # 火刀期身上一直冒火苗(站着也冒)
			_spawn_oneshot_particles(LAMP_IGNITE_EFFECT_SCENE)  # 橙色升腾:心跳点燃


## 冲刺开始/结束(Sprint 状态调用)。
func on_sprint_started() -> void:
	_end_mist()  # 冲刺破雾
	# 蓝水晶:每次冲刺都被水晶包裹(原来带8s冷却,太弱,2026-08-25去掉)
	if has_buff(&"BlueCrystal"):
		crystal_dash_active = true
		set_effect_overlay(blue_crystal_overlay, true)
		_spawn_oneshot_particles(CRYSTAL_DASH_EFFECT_SCENE)  # 冰蓝迸发:水晶成形


func on_sprint_ended() -> void:
	if crystal_dash_active:
		crystal_dash_active = false
		set_effect_overlay(blue_crystal_overlay, false)
	if has_buff(&"Watertank"):
		tide_next_hit = true


## 珊瑚潮汐:破盾时朝上半圈射出扇形 7 根水刺(以正上为 0°,每 30° 一根,
## 从左平射扫到右平射)。向下那根打地板没意义,砍掉了。
## 命中 ≥ TIDE_RING_BONUS_HITS 根 → 下一击再+50%(与冲刺强化加法叠加;
## 扇形大半朝天,"全中"不现实,改成够数即触发)。
func _fire_tide_ring() -> void:
	var scene := get_tree().current_scene
	if scene == null:
		return
	_tide_ring_hits = 0
	_tide_ring_pending = 0
	for deg in [-90, -60, -30, 0, 30, 60, 90]:
		var rad := deg_to_rad(float(deg))
		var dir := Vector2(sin(rad), -cos(rad))
		var spike := TIDE_SPIKE_SCENE.instantiate() as Area2D
		scene.add_child(spike)
		spike.global_position = global_position
		spike.call("setup", dir, TIDE_SPIKE_DAMAGE)
		spike.scale *= TIDE_SPIKE_SCALE  # setup 里可能镜像了 scale.x,只能乘不能盖
		spike.connect("hit_landed", _on_tide_spike_hit)
		spike.tree_exited.connect(_on_tide_spike_gone)
		_tide_ring_pending += 1
	# 潮汐涌出的反馈:淡青色闪屏,让破盾瞬间一眼可见。
	Game.flash(0.18, Color(0.55, 0.9, 1.0, 0.5))


func _on_tide_spike_hit() -> void:
	_tide_ring_hits += 1


func _on_tide_spike_gone() -> void:
	if not is_inside_tree():
		return  # 换场景的连锁销毁,别再结算
	_tide_ring_pending -= 1
	if _tide_ring_pending == 0 and _tide_ring_hits >= TIDE_RING_BONUS_HITS:
		tide_ring_bonus = true


## 蜘蛛的伪装:有 buff 就自动带着漂浮卵(格林之子式常驻仆从),放下即收回。
func _update_egg_companion() -> void:
	if has_buff(&"SpiderQueenDoll"):
		if is_instance_valid(_egg):
			return
		var scene := get_tree().current_scene
		if scene == null:
			return
		_egg = EGG_SCENE.instantiate() as Node2D
		scene.add_child(_egg)
		_egg.call("setup", self)
	elif is_instance_valid(_egg):
		_egg.call("despawn")
		_egg = null


## 召唤物快照用:主角此刻的单发攻击力(一段基础伤 × 破盾/花/红水晶倍率)。
func snapshot_attack_power() -> int:
	var attack_state: Node = state_machine.get_node(^"Attack1(9)")
	var base: float = float(attack_state.ATTACK1_1_DAMAGE)
	var bonus: float = 0.0
	if not is_guarding or has_buff(&"Flower"):
		bonus = attack_state.RED_CRYSTAL_NO_SHIELD_BONUS \
			if has_buff(&"RedCrystal") else attack_state.NO_SHIELD_BONUS
	return int(round(base * (1.0 + bonus)))


## 礼拜日的云雾:F 隐入雾中(半透明+完全无敌),攻击/冲刺立刻破雾。
func _try_start_mist() -> void:
	if not has_buff(&"YunwuPaint") or mist_active or mist_cooldown_left > 0.0:
		return
	mist_active = true
	_mist_left = MIST_DURATION


func _end_mist() -> void:
	if not mist_active:
		return
	mist_active = false
	mist_cooldown_left = MIST_COOLDOWN


## 沐子的守望:无盾被碰不死,带一层盾原地站起来。用掉后守望"破碎"
## (HUD 图标换成碎的),直到下一次出生才复原。
func _muzi_revive() -> void:
	Story.set_muzi_broken(true)
	is_guarding = true
	guard_slot = 0
	shield_ready[0] = true
	shield_recharge[0] = 0.0
	_refresh_shield_visual()
	shield_changed.emit()
	_spawn_oneshot_particles(MUZI_REVIVE_EFFECT_SCENE)  # 红色迸发:守望碎裂
	Game.flash(0.35, Color(1.0, 1.0, 1.0, 1.0))
	Game.shake_camera(3)
	_start_invincibility(MUZI_REVIVE_INVINCIBLE)


# ============================================================
# 跨房间状态继承(无提示自动过门用,Game.change_scene 调)
# ============================================================
# 换场景后新场景里是全新的 Player 实例,_ready 会把一切充满/复原。
# 自动过门(auto_teleport)语义上只是"走进隔壁房间",不该白送满盾:
# 切场景前拍下运行态,新实例就位后原样恢复。
func capture_state_snapshot() -> Dictionary:
	return {
		"shield_ready": shield_ready.duplicate(),
		"shield_recharge": shield_recharge.duplicate(),
		"is_guarding": is_guarding,
		"guard_slot": guard_slot,
		"tide_next_hit": tide_next_hit,
		"tide_ring_bonus": tide_ring_bonus,
		"lamp_energy": _lamp_energy,
		"lamp_fire_left": _lamp_fire_left,
		"window_ramp": _window_ramp,
		"mist_active": mist_active,
		"mist_left": _mist_left,
		"mist_cooldown_left": mist_cooldown_left,
		"muzi_broken": Story.muzi_broken,
		"dev_god_mode": dev_god_mode,
	}


func apply_state_snapshot(data: Dictionary) -> void:
	# 护盾:布局已在 _ready 按 buff 重建,层数一致才逐槽恢复
	# (对不上说明途中 buff 变了,保持重建后的状态,别硬塞旧数组)。
	var saved_ready = data.get("shield_ready")
	var saved_recharge = data.get("shield_recharge")
	if saved_ready is Array and saved_recharge is Array \
			and (saved_ready as Array).size() == shield_ready.size() \
			and (saved_recharge as Array).size() == shield_recharge.size():
		for i in shield_ready.size():
			shield_ready[i] = bool(saved_ready[i])
			shield_recharge[i] = float(saved_recharge[i])
		is_guarding = bool(data.get("is_guarding", is_guarding))
		guard_slot = int(data.get("guard_slot", guard_slot))
	tide_next_hit = bool(data.get("tide_next_hit", false))
	tide_ring_bonus = bool(data.get("tide_ring_bonus", false))
	_lamp_energy = int(data.get("lamp_energy", 0))
	_lamp_fire_left = float(data.get("lamp_fire_left", 0.0))
	_window_ramp = float(data.get("window_ramp", 0.0))
	mist_active = bool(data.get("mist_active", false))
	_mist_left = float(data.get("mist_left", 0.0))
	mist_cooldown_left = float(data.get("mist_cooldown_left", 0.0))
	# _ready 里把守望复原过了(那是给"新的一次出生"的),过门要接着旧账走。
	Story.set_muzi_broken(bool(data.get("muzi_broken", false)))
	if bool(data.get("dev_god_mode", false)) and not dev_god_mode:
		dev_god_mode = true
		modulate = _base_modulate * DEV_GOD_TINT
	# 铜灯火光还在烧的话,overlay 和火苗跟上(雾/潮汐水珠由每帧逻辑自理)。
	set_effect_overlay(fire_attack_overlay, _lamp_fire_left > 0.0)
	fire_aura.emitting = _lamp_fire_left > 0.0
	_refresh_shield_visual()
	shield_changed.emit()


var reached_terminal: bool = false
var coyote_timer: float = 0.0
var jump_buffer_timer: float = 0.0

func apply_gravity(delta: float, multiplier: float = 1.0) -> void:
	# Apply gravity and clamp to terminal velocity. Mark if terminal reached.
	velocity.y += GRAVITY * multiplier * delta
	if velocity.y > MAX_FALL_SPEED:
		velocity.y = MAX_FALL_SPEED
		reached_terminal = true

func set_ball_form(enabled: bool) -> void:
	is_in_ball_form = enabled
	collision_normal.disabled = enabled
	collision_ball.disabled = not enabled

func set_walking_effect(enabled: bool) -> void:
	_walking_effect_enabled = enabled
	_apply_walking_effect()

# 走路特效二选一:有盾发 ShieldPlayerWalkingEffect,无盾发 PlayerWalkingEffect。
func _apply_walking_effect() -> void:
	if is_instance_valid(walking_effect):
		walking_effect.emitting = _walking_effect_enabled and not is_guarding
	if is_instance_valid(shield_walking_effect):
		shield_walking_effect.emitting = _walking_effect_enabled and is_guarding

# 跳跃像素残影拖尾开关(由跳跃状态调用,落地时关闭)。
func set_jump_trail(enabled: bool) -> void:
	if is_instance_valid(jump_trail) and jump_trail.has_method("set_active"):
		jump_trail.call("set_active", enabled)

func spawn_landing_effect() -> void:
	# 落地特效二选一:有盾用护盾版本。
	_spawn_oneshot_particles(SHIELD_LANDING_EFFECT_SCENE if is_guarding else LANDING_EFFECT_SCENE)

# 在主角位置放一个一次性粒子特效,播完自动清掉。
func _spawn_oneshot_particles(scene: PackedScene) -> void:
	if not is_inside_tree() or scene == null:
		return
	var effect := scene.instantiate() as GPUParticles2D
	if effect == null:
		return
	effect.one_shot = true
	effect.emitting = true
	if get_tree().current_scene == null:
		effect.queue_free()
		return
	get_tree().current_scene.add_child(effect)
	effect.global_position = global_position
	await get_tree().create_timer(effect.lifetime).timeout
	if is_instance_valid(effect):
		effect.queue_free()

func spawn_hit_effect(posx: float) -> void:
	if not is_inside_tree() or HIT_EFFECT_SCENE == null:
		return
	var effect := HIT_EFFECT_SCENE.instantiate() as GPUParticles2D
	if effect == null:
		return
	effect.one_shot = true
	effect.emitting = true
	if get_tree().current_scene == null:
		effect.queue_free()
		return
	get_tree().current_scene.add_child(effect)
	effect.global_position = Vector2(posx, $HitBox/HitEffectPosition.global_position.y)
	await get_tree().create_timer(effect.lifetime).timeout
	if is_instance_valid(effect):
		effect.queue_free()

func spawn_jump_attack_effect(posx: float) -> void:
	if not is_inside_tree() or JUMP_ATTACK_EFFECT_SCENE == null:
		return
	var effect := JUMP_ATTACK_EFFECT_SCENE.instantiate() as GPUParticles2D
	if effect == null:
		return
	effect.one_shot = true
	effect.emitting = true
	if get_tree().current_scene == null:
		effect.queue_free()
		return
	get_tree().current_scene.add_child(effect)
	effect.global_position = Vector2(posx, $HitBox/HitEffectPosition.global_position.y)
	await get_tree().create_timer(effect.lifetime).timeout
	if is_instance_valid(effect):
		effect.queue_free()

func set_facing_direction(direction: int) -> void:
	if direction == 0:
		return
	facing_direction = sign(direction)
	var scale_x := absf(sprite.scale.x)
	if scale_x == 0.0:
		scale_x = 1.0
	sprite.scale.x = scale_x * float(facing_direction)
	if is_instance_valid(hitbox_root):
		var hitbox_scale_x := absf(hitbox_root.scale.x)
		if hitbox_scale_x == 0.0:
			hitbox_scale_x = 1.0
		hitbox_root.scale.x = hitbox_scale_x * float(facing_direction)

func enter_ball_form() -> void:
	set_ball_form(true)

func exit_ball_form() -> void:
	set_ball_form(false)

func start_attack() -> void:
	_end_mist()  # 出手破雾
	clear_attack_hitboxes()
	change_state(STATE_ATTACK_1)

func set_attack_hitbox(stage: int, enabled: bool = true) -> void:
	if stage == 1:
		if is_instance_valid(attack_hitbox_1):
			attack_hitbox_1.monitoring = enabled
		if is_instance_valid(attack_hitbox_2):
			attack_hitbox_2.monitoring = false
		return

	if stage == 2:
		if is_instance_valid(attack_hitbox_1):
			attack_hitbox_1.monitoring = false
		if is_instance_valid(attack_hitbox_2):
			attack_hitbox_2.monitoring = enabled
		return

	clear_attack_hitboxes()

func clear_attack_hitboxes() -> void:
	if is_instance_valid(attack_hitbox_1):
		attack_hitbox_1.monitoring = false
	if is_instance_valid(attack_hitbox_2):
		attack_hitbox_2.monitoring = false

func finish_attack() -> void:
	clear_attack_hitboxes()
	if is_in_ball_form:
		change_state(STATE_BALL)
		return
	if not is_on_floor():
		change_state(STATE_FALL)
		return
	var move_input := Input.get_axis(&"move_left", &"move_right")
	if abs(move_input) > 0.0:
		change_state(STATE_RUN)
	else:
		change_state(STATE_IDLE)
